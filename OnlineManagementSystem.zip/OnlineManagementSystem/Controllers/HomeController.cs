﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineManagementSystem.Models;
using System.Data;

namespace OnlineManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        RegisterDetailsModel rg = new RegisterDetailsModel();
        DataSet ds;
        public ActionResult About(string status)
        {
            if (status == "LoggedIn")
            {
                if (Session["LoggedInUserID"] != null)
                {
                    ViewBag.IsUserLoggedIn = 1;
                }
                else
                {
                    ViewBag.IsUserLoggedIn = 0;
                }
            } 
            else
            {
                ViewBag.IsUserLoggedIn = 0;
            }

            return View();
        }

        public ActionResult Register()
        {
           return View();
        }

        public ActionResult Login()
        {
            Session["LoggedInUserID"] = null;
            return View();
        }

        [HttpPost]
        public ActionResult Register(RegisterDetailsModel reg)
        {
            if (ModelState.IsValid)
            {
                bool val = rg.InsertUserDetails(reg);
                if (val == true)
                {
                    return RedirectToAction("Login", "Home");
                }
                else
                {
                    TempData["Errormsg"] = "<label>Email ID already used</label>";
                    return View();
                }
            }

            return View(rg);
        }

        [HttpPost]
        public ActionResult Login(RegisterDetailsModel reg)
        {
            ds = new DataSet();                
            ds = rg.GetUserDetails(reg);
            foreach(DataRow dr in ds.Tables[0].Rows)
            {
                rg.LoginID = Int32.Parse(dr[0].ToString());
                rg.FirstName = dr[1].ToString();
                rg.LastName = dr[2].ToString();
            }

            if (rg.LoginID > 0)
            {
                return RedirectToAction("Dashboard", "ManageTask", rg);
            }
            else
            {
                TempData["Errormsg"] = "<label>Incorrect Email ID or Password</label>";
                return View();
            }           
        }
    }
}