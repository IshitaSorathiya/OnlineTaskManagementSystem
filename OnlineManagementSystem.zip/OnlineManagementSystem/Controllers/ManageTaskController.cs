﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using OnlineManagementSystem.Models;
using OnlineManagementSystem.App_Code;
using System.Net.Mail;
using System.Text;

namespace OnlineManagementSystem.Controllers
{
    public class ManageTaskController : Controller
    {
        ManageTaskService mts = new ManageTaskService();
        ManageTaskModel mtm = new ManageTaskModel();

        public ActionResult Dashboard(RegisterDetailsModel reg)
        {
            ViewBag.IsUserLoggedIn = 1;
            Session["LoggedInUserID"] = reg.LoginID;
            ViewBag.UserName = reg.FirstName + " " + reg.LastName;
            Session["UserName"] = ViewBag.UserName;
            return View();
        }

        [HttpPost]
        public ActionResult GetBoard(string TaskType)
        {
            DataSet ds = new DataSet();
            String JsonString = String.Empty;
            mtm.BoardType = TaskType;
            mtm.LoginID = Int32.Parse(Session["LoggedInUserID"].ToString());
            ds = mts.GetBoardDetails(mtm);
            JsonString = JsonConvert.SerializeObject(ds);
            return Json(JsonString);
        }

        [HttpPost]
        public ActionResult GetTask(int BoardId, string TaskType)
        {
            DataSet ds = new DataSet();
            String JsonString = String.Empty;
            mtm.BoardType = TaskType;
            mtm.BoardId = BoardId;
            ds = mts.GetTaskDetails(mtm);
            JsonString = JsonConvert.SerializeObject(ds);
            return Json(JsonString);
        }

        [HttpPost]
        public ActionResult DeleteTask(int TaskId, string TaskType)
        {
            String JsonString = String.Empty;
            mtm.BoardType = TaskType;
            mtm.TaskId = TaskId;
            int BoardId = mts.DeleteTaskDetails(mtm);
            JsonString = JsonConvert.SerializeObject(BoardId);
            return Json(JsonString);
        }

        [HttpPost]
        public ActionResult UpdateTask(int TaskId, string TaskType, string TextValue)
        {
            String JsonString = String.Empty;
            mtm.BoardType = TaskType;
            mtm.TaskId = TaskId;
            mtm.TextValue = TextValue;
            int BoardId = mts.UpdateTaskDetails(mtm);
            JsonString = JsonConvert.SerializeObject(BoardId);
            return Json(JsonString);
        }

        [HttpPost]
        public ActionResult CreateTask(int BoardId, string TaskType, string TextValue)
        {
            String JsonString = String.Empty;
            mtm.BoardType = TaskType;
            mtm.BoardId = BoardId;
            mtm.TextValue = TextValue;
            bool result = mts.CreateTaskDetails(mtm);
            JsonString = JsonConvert.SerializeObject(result);
            return Json(JsonString);
        }

        [HttpPost]
        public ActionResult CreateBoard(string TaskType, string TxtValue)
        {
            String JsonString = String.Empty;
            mtm.BoardType = TaskType;
            mtm.TextValue = TxtValue;
            mtm.LoginID = Int32.Parse(Session["LoggedInUserID"].ToString());
            bool result = mts.CreateBoard(mtm);
            JsonString = JsonConvert.SerializeObject(result);
            return Json(JsonString);
        }

        [HttpPost]
        public ActionResult UpdateBoard(int BoardId, string TaskType, string TextValue)
        {
            String JsonString = String.Empty;
            mtm.BoardType = TaskType;
            mtm.BoardId = BoardId;
            mtm.TextValue = TextValue;
            bool result = mts.UpdateBoardDetails(mtm);
            JsonString = JsonConvert.SerializeObject(BoardId);
            return Json(JsonString);
        }

        [HttpPost]
        public ActionResult DeleteBoard(int BoardId, string TaskType)
        {
            String JsonString = String.Empty;
            mtm.BoardType = TaskType;
            mtm.BoardId = BoardId;
            bool result = mts.DeleteBoardDetails(mtm);
            JsonString = JsonConvert.SerializeObject(BoardId);
            return Json(JsonString);
        }

        [HttpPost]
        public ActionResult ShareTask(int BoardId, string TaskType, string UserEmailID)
        {
            String JsonString = String.Empty;
            mtm.BoardType = TaskType;
            mtm.BoardId = BoardId;
            mtm.LoginID = Int32.Parse(Session["LoggedInUserID"].ToString());
            mtm.UserEmailID = UserEmailID;
            bool result = mts.ShareBoardDetails(mtm);
            JsonString = JsonConvert.SerializeObject(BoardId);
            return Json(JsonString);
        }
    }
}