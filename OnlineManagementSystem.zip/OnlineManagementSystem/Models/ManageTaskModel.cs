﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace OnlineManagementSystem.Models
{
    public class ManageTaskModel
    {
        public int LoginID { get; set; }

        public string BoardType { get; set; }

        public int BoardId { get; set; }

        public int TaskId { get; set; }

        public string TextValue { get; set; }

        [Required(ErrorMessage = "Please Enter Email ID")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "E-mail is not valid")]
        public string UserEmailID { get; set; }
    }
}