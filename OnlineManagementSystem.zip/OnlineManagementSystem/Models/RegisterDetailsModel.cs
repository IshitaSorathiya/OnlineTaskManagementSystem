﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace OnlineManagementSystem.Models
{
    public class RegisterDetailsModel
    {
        [Required(ErrorMessage = "Please Enter your First Name")]
        public String FirstName { get; set; }

        [Required(ErrorMessage = "Please Enter your Last Name")]
        public String LastName { get; set; }

        [Required(ErrorMessage = "Please Enter Email ID")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "E-mail is not valid")]
        public String EmailID { get; set; }

        [Required(ErrorMessage = "Please Enter the Password")]
        [StringLength(15, ErrorMessage = "Password should be 8 characters long", MinimumLength = 8)]
        public String Password { get; set; }

        [Required(ErrorMessage = "Please confirm the Password")]
        [Compare("Password", ErrorMessage = "Confirm Password should match the entered Psssword")]
        public String ConfirmPassword { get; set; }

        public String LabelMessage { get; set; }

        public int LoginID { get; set; }

        String constr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
        SqlConnection con;
        DataSet ds = new DataSet();

        public Boolean InsertUserDetails(RegisterDetailsModel reg)
        {
            try
            {
                con = new SqlConnection(constr);

                con.Open();
                SqlCommand dCmd = new SqlCommand("LoginDetailsInsert", con);
                dCmd.CommandType = CommandType.StoredProcedure;
                dCmd.Parameters.Add(new SqlParameter("@FirstName", reg.FirstName));
                dCmd.Parameters.Add(new SqlParameter("@LastName", reg.LastName));
                dCmd.Parameters.Add(new SqlParameter("@EmailID", reg.EmailID));
                dCmd.Parameters.Add(new SqlParameter("@Password", reg.Password));
                int i = Int32.Parse(dCmd.ExecuteScalar().ToString());
                con.Close();

                if (i > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception e)
            {
                throw e;
            }
        }

        public DataSet GetUserDetails(RegisterDetailsModel reg)
        {
            try
            {
                SqlConnection con = new SqlConnection(constr);

                con.Open();
                SqlCommand dCmd = new SqlCommand("LoginDetailsGetDetails", con);
                dCmd.CommandType = CommandType.StoredProcedure;
                dCmd.Parameters.Add(new SqlParameter("@EmailID", reg.EmailID));
                dCmd.Parameters.Add(new SqlParameter("@Password", reg.Password));
                SqlDataAdapter da = new SqlDataAdapter(dCmd);
                da.Fill(ds);
                con.Close();

                return ds;
            }
            catch(Exception e)
            {
                throw e;
            }
        }
    }
}